Project that implements privacy-preserving process discovery using connector method.
