from p_connector_dfg import privacyPreserving, Utilities

__name__ = 'p_connector_dfg'
__version__ = '0.0.13'
__doc__ = "Privacy-preserving Process Discovery Using Connector Method"
__author__ = 'Majid Rafiei'
__author_email__ = 'majid.rafiei@pads.rwth-aachen.de'
__maintainer__ = 'Majid Rafiei'
__maintainer_email__ = "majid.rafiei@pads.rwth-aachen.de"
